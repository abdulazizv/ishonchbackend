export class VerifyOtpDto {
    readonly phone_number:string
    readonly otp_code:number;
}