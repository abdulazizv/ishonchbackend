export class CreateOtpDto {}
