export class CreateLlDto {}
