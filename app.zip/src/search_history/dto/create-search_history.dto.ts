export class CreateSearchHistoryDto {}
