export type JwtPayload = {
    sub: number;
    is_active:boolean;
    is_admin:boolean;
    is_creator:boolean;
};